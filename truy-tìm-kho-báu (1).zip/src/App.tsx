import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Settings, 
  Users, 
  HelpCircle, 
  Sparkles, 
  MapPin, 
  Tv2, 
  ShieldCheck, 
  Lock, 
  BookOpen, 
  RefreshCw 
} from 'lucide-react';
import StudentAdventure from './components/StudentAdventure';
import TeacherPanel from './components/TeacherPanel';
import { Question } from './types';

export default function App() {
  const [currentRole, setCurrentRole] = useState<'student' | 'teacher'>('student');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isGameActive, setIsGameActive] = useState(false);
  const [gameTimeLimit, setGameTimeLimit] = useState<number>(30); // Default to 30 minutes, 0 means unlimited
  const [loading, setLoading] = useState(true);
  const [teacherPass, setTeacherPass] = useState('');
  const [teacherAuthenticated, setTeacherAuthenticated] = useState(false);
  const [authError, setAuthError] = useState('');

  // Settle question template downloads on mount
  const loadQuestions = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/questions');
      const data = await response.json();
      if (data.questions) {
        setQuestions(data.questions);
      }
      if (typeof data.isGameActive === 'boolean') {
        setIsGameActive(data.isGameActive);
      }
      if (typeof data.gameTimeLimit === 'number') {
        setGameTimeLimit(data.gameTimeLimit);
      }
    } catch (err) {
      console.error("Error loaded questions from custom Express bank fallback:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQuestions();
  }, []);

  const handleUpdateQuestionsInBank = (newQuestions: Question[]) => {
    setQuestions(newQuestions);
    setIsGameActive(true); // Any new custom questions uploaded / compiled from file instantly activates the game!
    // Sync updated questions to server backend for full persistence and alignment
    fetch('/api/questions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ questions: newQuestions })
    }).catch(console.error);
    syncGameStatusToBackend(true);
  };

  const syncGameStatusToBackend = async (newActive: boolean) => {
    try {
      const response = await fetch('/api/game-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: newActive })
      });
      const data = await response.json();
      if (data.success) {
        setIsGameActive(newActive);
      }
    } catch (err) {
      console.error("Error syncing game status:", err);
    }
  };

  const syncGameTimeLimitToBackend = async (newLimit: number) => {
    try {
      const response = await fetch('/api/game-time', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timeLimit: newLimit })
      });
      const data = await response.json();
      if (data.success) {
        setGameTimeLimit(newLimit);
      }
    } catch (err) {
      console.error("Error syncing game time limit:", err);
    }
  };

  const handleTeacherLogIn = (e: React.FormEvent) => {
    e.preventDefault();
    const customStoredPass = localStorage.getItem('teacher_password');
    const entered = teacherPass.trim();
    
    let isCorrect = false;
    if (customStoredPass) {
      isCorrect = (entered === customStoredPass);
    } else {
      isCorrect = (entered.toUpperCase() === 'DUNGMATH' || entered === '123456');
    }

    if (isCorrect) {
      setTeacherAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError('Mật khẩu quản trị chưa chính xác! Vui lòng liên hệ Thầy Phạm Văn Dũng.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased selection:bg-emerald-500 selection:text-white pb-12 transition">
      
      {/* Decorative top ambient flow */}
      <div className="w-full bg-gradient-to-r from-emerald-600 via-teal-700 to-indigo-800 text-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Logo / Title Brand area */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-yellow-400 text-slate-950 flex items-center justify-center rounded-xl shadow-inner font-black text-xl animate-spin-slow">
              ⭐
            </div>
            <div className="text-left">
              <h1 className="text-lg md:text-xl font-display font-black tracking-tight flex items-center gap-1.5 uppercase">
                Truy Tìm Kho Báu Toán Học
                <span className="bg-yellow-400 text-slate-950 text-[10px] font-bold py-0.5 px-2 rounded-full normal-case tracking-normal">2D Game</span>
              </h1>
              <p className="text-[10px] text-emerald-100 font-medium">Hệ Thống Phối Hợp Giáo Dục Trực Tuyến & Master AI Agent</p>
            </div>
          </div>

          {/* Quick Role switches */}
          <div className="flex bg-black/25 relative p-1 rounded-xl border border-white/10 shrink-0 select-none">
            <button
              onClick={() => setCurrentRole('student')}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                currentRole === 'student'
                  ? 'bg-white text-slate-950 shadow font-extrabold'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              <span>🎮 Học Sinh Chơi</span>
            </button>
            <button
              onClick={() => setCurrentRole('teacher')}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                currentRole === 'teacher'
                  ? 'bg-white text-slate-950 shadow font-extrabold'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              <span>🏫 Giáo Viên Quản Trị</span>
            </button>
          </div>

        </div>
      </div>

      {loading ? (
        /* Global Fallback Loader spinner */
        <div className="flex flex-col items-center justify-center py-32 gap-3 max-w-sm mx-auto">
          <RefreshCw className="w-10 h-10 animate-spin text-emerald-600" />
          <p className="text-xs text-slate-500 font-mono italic">Đang tải cấu phông ngân hàng 22 trạm toán học từ máy chủ...</p>
        </div>
      ) : (
        /* Dynamic Screen Router */
        <main className="transition duration-150">
          {currentRole === 'student' ? (
            /* Student play screen area */
            <StudentAdventure 
              questions={questions}
              isGameActive={isGameActive}
              gameTimeLimit={gameTimeLimit}
              onGameFinished={(score, state) => {
                console.log("Game finished callback received:", score, state);
              }}
              onRefreshGameStatus={loadQuestions}
            />
          ) : (
            /* Teacher dashboard guard screen or authenticated board */
            <div className="max-w-6xl mx-auto px-4 mt-6">
              {!teacherAuthenticated ? (
                /* Authenticated lock gateway */
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-2xl border p-8 max-w-md mx-auto shadow-lg text-center mt-12 space-y-6"
                >
                  <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
                    <Lock className="w-8 h-8" />
                  </div>

                  <div>
                    <h3 className="text-xl font-display font-bold text-slate-950">Xác Minh Danh Tính Giáo Viên</h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Vui lòng nhập mật khẩu quản lý học liệu của <b>Thầy Phạm Văn Dũng</b> để tiếp tục.
                    </p>
                  </div>

                  <form onSubmit={handleTeacherLogIn} className="space-y-4 text-left">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Mật khẩu giáo viên</label>
                      <input
                        type="password"
                        placeholder="Nhập DUNGMATH hoặc mật khẩu mới của Thầy"
                        value={teacherPass}
                        onChange={(e) => setTeacherPass(e.target.value)}
                        className="w-full border rounded-xl py-2.5 px-4 text-slate-900 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-semibold"
                        autoFocus
                      />
                    </div>

                    {authError && (
                      <p className="text-red-600 text-xs font-semibold bg-red-50 p-2.5 rounded-lg border border-red-100">
                        {authError}
                      </p>
                    )}

                    <button
                      type="submit"
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 px-4 rounded-xl text-xs uppercase tracking-wider transition cursor-pointer"
                    >
                      Bảo mộc đăng nhập
                    </button>
                  </form>

                  <div className="pt-4 border-t border-slate-100 text-[10px] text-rose-500 font-bold bg-rose-50 p-2.5 rounded-lg">
                    🔒 Khu vực hạn chế: Chỉ dành riêng cho Giáo viên Phạm Văn Dũng quản trị chuyên môn. Học sinh không được phép truy cập vào mục này.
                  </div>
                </motion.div>
              ) : (
                /* Authenticated Teacher Panel board content */
                <TeacherPanel 
                  questions={questions}
                  isGameActive={isGameActive}
                  gameTimeLimit={gameTimeLimit}
                  onUpdateQuestions={handleUpdateQuestionsInBank}
                  onChangeGameActive={syncGameStatusToBackend}
                  onChangeGameTimeLimit={syncGameTimeLimitToBackend}
                />
              )}
            </div>
          )}
        </main>
      )}

      {/* Shared human footer */}
      <footer className="mt-16 text-center text-[11px] text-slate-400 space-y-1 font-medium select-none">
        <p>© 2026 Bản quyền phân hiệu thuộc về Giáo viên Toán học: <b>Phạm Văn Dũng</b></p>
        <p className="text-slate-300">Vận hành đồng bộ bởi AI Game Master Central Gateway • Server Fullstack Ready</p>
      </footer>

    </div>
  );
}
